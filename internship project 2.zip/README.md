# 🤖 GenAI Content Engine

Implements all 4 steps from the Deployment Checklist:
1. Pydantic Models — strict output schemas
2. CLI (argparse) — product variables, tone modifiers, target platforms
3. Master Template (f-strings) — brand safety + platform constraints
4. Dual-Pipeline — asyncio.gather + Semaphore (real-time) / sequential batch (bulk)

---

## ⚙️ Setup

### 1. Install Python 3.11+
Download from https://python.org if not installed.

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set your Anthropic API Key
**Windows (CMD):**
```cmd
set ANTHROPIC_API_KEY=sk-ant-...your-key-here...
```
**Mac/Linux:**
```bash
export ANTHROPIC_API_KEY=sk-ant-...your-key-here...
```
Get your key at: https://console.anthropic.com

---

## 🚀 Run It

### Single platform (real-time pipeline):
```bash
python main.py --product "EchoNote AI" --desc "AI-powered note-taking app that summarizes meetings" --tone professional --platform linkedin
```

### All platforms at once (bulk pipeline):
```bash
python main.py --product "EchoNote AI" --desc "AI-powered note-taking app that summarizes meetings" --tone witty --bulk
```

### Tone options: `professional` | `casual` | `witty` | `urgent`
### Platform options: `twitter` | `linkedin` | `email` | `instagram`

---

## 📁 Project Structure
```
genai_content_engine/
├── main.py           # Full engine (all 4 checklist steps)
├── requirements.txt  # Dependencies
└── README.md         # This file
```
