"""
Generative AI Content Engine
Implements the 4-step Deployment Checklist:
  1. Pydantic Models
  2. CLI with argparse
  3. Master Template (f-strings)
  4. Dual-Pipeline (asyncio + openbatch simulation)
"""

import asyncio
import argparse
import json
import time
from pydantic import BaseModel, Field
from typing import Literal
from anthropic import Anthropic

# ─────────────────────────────────────────────
# STEP 1: Define the Pydantic Models
# ─────────────────────────────────────────────

class ContentRequest(BaseModel):
    product_name: str = Field(..., description="Name of the product")
    product_description: str = Field(..., description="What the product does")
    tone: Literal["professional", "casual", "witty", "urgent"] = Field(default="professional")
    platform: Literal["twitter", "linkedin", "email", "instagram"] = Field(default="linkedin")

class GeneratedCopy(BaseModel):
    headline: str = Field(..., description="Main headline")
    body: str = Field(..., description="Body copy")
    cta: str = Field(..., description="Call to action")
    hashtags: list[str] = Field(default_factory=list)
    platform: str
    tone_used: str

# ─────────────────────────────────────────────
# STEP 3: Build the Master Template
# ─────────────────────────────────────────────

BRAND_SAFETY_GUIDELINES = """
- No exaggerated claims (e.g., "best ever", "guaranteed")
- No offensive or divisive language
- No competitor mentions
- Keep it factual and benefit-focused
"""

PLATFORM_CONSTRAINTS = {
    "twitter":   {"max_chars": 280,  "hashtags": 2, "tone_note": "punchy and short"},
    "linkedin":  {"max_chars": 700,  "hashtags": 3, "tone_note": "professional and insightful"},
    "email":     {"max_chars": 1500, "hashtags": 0, "tone_note": "direct and persuasive"},
    "instagram": {"max_chars": 400,  "hashtags": 5, "tone_note": "visual and engaging"},
}

def build_master_template(req: ContentRequest) -> str:
    constraints = PLATFORM_CONSTRAINTS[req.platform]
    return f"""You are an expert copywriter. Generate marketing copy for the following product.

PRODUCT: {req.product_name}
DESCRIPTION: {req.product_description}
TONE: {req.tone} — {constraints['tone_note']}
PLATFORM: {req.platform.upper()}

PLATFORM CONSTRAINTS:
- Max characters: {constraints['max_chars']}
- Hashtags to include: {constraints['hashtags']}

BRAND SAFETY GUIDELINES:
{BRAND_SAFETY_GUIDELINES}

Respond ONLY with valid JSON in this exact format:
{{
  "headline": "...",
  "body": "...",
  "cta": "...",
  "hashtags": ["tag1", "tag2"],
  "platform": "{req.platform}",
  "tone_used": "{req.tone}"
}}"""

# ─────────────────────────────────────────────
# STEP 4: Implement the Dual-Pipeline
# ─────────────────────────────────────────────

client = Anthropic()
semaphore = asyncio.Semaphore(3)  # max 3 concurrent real-time requests

async def generate_single(req: ContentRequest) -> GeneratedCopy:
    """Real-time pipeline: asyncio.gather with Semaphore."""
    async with semaphore:
        prompt = build_master_template(req)
        loop = asyncio.get_event_loop()

        def call_api():
            response = client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text

        raw = await loop.run_in_executor(None, call_api)

        # Parse JSON response
        raw = raw.strip().replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        return GeneratedCopy(**data)


async def realtime_pipeline(requests: list[ContentRequest]) -> list[GeneratedCopy]:
    """Run multiple requests concurrently with semaphore control."""
    print(f"\n🚀 Real-Time Pipeline: Processing {len(requests)} request(s) concurrently...\n")
    tasks = [generate_single(req) for req in requests]
    results = await asyncio.gather(*tasks)
    return list(results)


def bulk_pipeline(requests: list[ContentRequest]) -> list[GeneratedCopy]:
    """Bulk pipeline: sequential batch processing (openbatch-style)."""
    print(f"\n📦 Bulk Pipeline: Processing {len(requests)} request(s) sequentially...\n")
    results = []
    for i, req in enumerate(requests, 1):
        print(f"  ⏳ Batch item {i}/{len(requests)}: {req.product_name} → {req.platform}")
        prompt = build_master_template(req)
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = response.content[0].text.strip().replace("```json", "").replace("```", "").strip()
        data = json.loads(raw)
        result = GeneratedCopy(**data)
        results.append(result)
        time.sleep(0.3)  # polite rate limiting
    return results

# ─────────────────────────────────────────────
# Output Formatter
# ─────────────────────────────────────────────

def print_result(copy: GeneratedCopy):
    tags = " ".join(f"#{t.lstrip('#')}" for t in copy.hashtags) if copy.hashtags else "None"
    print(f"""
┌─────────────────────────────────────────┐
│  Platform : {copy.platform.upper():<29}│
│  Tone     : {copy.tone_used:<29}│
└─────────────────────────────────────────┘
📢 HEADLINE:
  {copy.headline}

📝 BODY:
  {copy.body}

👉 CTA:
  {copy.cta}

#️⃣  HASHTAGS:
  {tags}
""")

# ─────────────────────────────────────────────
# STEP 2: Configure the CLI
# ─────────────────────────────────────────────

def build_cli():
    parser = argparse.ArgumentParser(
        description="🤖 GenAI Content Engine — Transform product data into platform-ready copy",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Single real-time generation:
  python main.py --product "EchoNote AI" --desc "AI note-taking app" --tone professional --platform linkedin

  # Bulk mode (generates for ALL platforms):
  python main.py --product "EchoNote AI" --desc "AI note-taking app" --tone witty --bulk
        """
    )
    parser.add_argument("--product",  required=True, help="Product name")
    parser.add_argument("--desc",     required=True, help="Product description")
    parser.add_argument("--tone",     default="professional",
                        choices=["professional", "casual", "witty", "urgent"],
                        help="Tone modifier (default: professional)")
    parser.add_argument("--platform", default="linkedin",
                        choices=["twitter", "linkedin", "email", "instagram"],
                        help="Target platform (default: linkedin)")
    parser.add_argument("--bulk",     action="store_true",
                        help="Bulk mode: generate for ALL platforms concurrently")
    return parser


def main():
    parser = build_cli()
    args = parser.parse_args()

    print(f"\n✨ GenAI Content Engine Starting...")
    print(f"   Product : {args.product}")
    print(f"   Tone    : {args.tone}")
    print(f"   Mode    : {'BULK (all platforms)' if args.bulk else f'SINGLE ({args.platform})'}")

    if args.bulk:
        # Bulk pipeline across all platforms
        requests = [
            ContentRequest(
                product_name=args.product,
                product_description=args.desc,
                tone=args.tone,
                platform=p
            )
            for p in ["twitter", "linkedin", "email", "instagram"]
        ]
        results = bulk_pipeline(requests)
        print("\n" + "═"*45)
        print("  📋 BULK RESULTS")
        print("═"*45)
        for r in results:
            print_result(r)

    else:
        # Real-time single request
        req = ContentRequest(
            product_name=args.product,
            product_description=args.desc,
            tone=args.tone,
            platform=args.platform
        )
        results = asyncio.run(realtime_pipeline([req]))
        print("\n" + "═"*45)
        print("  ✅ GENERATED COPY")
        print("═"*45)
        for r in results:
            print_result(r)


if __name__ == "__main__":
    main()
